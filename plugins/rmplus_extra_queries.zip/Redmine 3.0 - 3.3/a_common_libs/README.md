Changelog:
  2.3.5
    * Speedup issues queries with CF multiple users column in list
  2.3.4
    * Fixed: loading path order
  2.3.3  
    * Fixed: minor bugs
  2.3.2
    * Added: compatibility to our plugins
  2.3.1
    * Added: refactored redmine custom_fields to speedup (need to be disabled)
    * Fixed: some sql extensions for different databases
    * Fixed: sql extension substring for mysql
  2.3.0
    * Added: log for api
    * Added: custom field Percent
  2.2.9
    * Added: jqPlot plugins
  2.2.8
    * Fixed: ajax_values permissions
  2.2.7
    * Fixed: support redmine < 3.0
  2.2.6
    * Added: fix for redmine 3.3
  2.2.5
    * Added: Updated FontAwesome
  2.2.4
    * Fixed: detecting favourite project for user without preferences
  2.2.3
    * fixed custom field order values for user type
    * new version of DatePicker
  2.2.2
    * fixed time queries
  2.2.0
    * fixed select2 styles
    * moved RM+ icon for email layout to our server
    * fixed fast-edit links for select2
    * support redmine 3.3.0
  2.1.9
    * select2 - 4.0.3
    * fixed modal windows
  2.1.8
    * fixed loading select2_extensions if select2 disabled
  2.1.7
    * moved helpers for postgreSQL
  2.1.6
    * add periodpicker
  2.1.5
    * dependency FontAwasome fot luxury_buttons
  2.1.0
    * refactored modal windows
  2.0.0
    * fixed auto-setting FontAwasome
  1.1.8
    * fixed auto-settings
  1.1.7
    * fixed favourite project sql to ansi sql
  1.1.6
    * added support for information about the license expiration
    * change Highcharts to jqPlot
  1.1.5:
    * added create_guid
    * modified modal_windows