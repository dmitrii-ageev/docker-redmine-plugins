Redmine::Plugin.register :global_roles do
  name 'Global Roles plugin'
  author 'Danil Kukhlevskiy'
  description 'This is a plugin for Redmine which provides usage of standart Roles privelegies for non-project objects.'
  version '2.2.0'
  url 'http://rmplus.pro/redmine/plugins/global_roles'
  author_url 'http://rmplus.pro'
end

require 'global_roles/view_hooks'

Rails.application.config.to_prepare do
  User.send(:include, GlobalRoles::UserPatch)
  Group.send(:include, GlobalRoles::GroupPatch)
  UsersHelper.send(:include, GlobalRoles::UsersHelperPatch)
  UsersController.send(:include, GlobalRoles::UsersControllerPatch)
  GroupsHelper.send(:include, GlobalRoles::GroupsHelperPatch)
  GroupsController.send(:include, GlobalRoles::GroupsControllerPatch)
  Role.send(:include, GlobalRoles::RolePatch)
  RolesController.send(:include, GlobalRoles::RolesControllerPatch)
  ApplicationController.send(:include, GlobalRoles::ApplicationControllerPatch)
  MemberRole.send(:include, GlobalRoles::MemberRolePatch)
  Redmine::AccessControl::Permission.send(:include, GlobalRoles::AccessControlPatch)
end

Rails.application.config.after_initialize do
  plugins = { a_common_libs: '2.1.0' }
  plugin = Redmine::Plugin.find(:global_roles)
  plugins.each do |k,v|
    begin
      plugin.requires_redmine_plugin(k, v)
    rescue Redmine::PluginNotFound => ex
      raise(Redmine::PluginNotFound, "Plugin requires #{k} not found")
    end
  end
end