= User Mentions plugin for Redmine
1.0.2
* Fixed: minor bug
1.0.1
* Added: support CKEditor